import 'dart:async';
import 'package:admin_portal/utils/raw_data.dart';
import 'package:admin_portal/widgets/log_tile.dart';
import 'package:admin_portal/widgets/ticket_cards.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  bool _isLoading = true;

  final logsRef = FirebaseFirestore.instance
      .collection('admin_panel')
      .doc('central_park')
      .collection('parking');

  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 1), () {
      setState(() {
        _isLoading = false;
      });
    });
  }

  customCard(Color color, String title, String number, IconData icon) {
    return Card(
      elevation: 2,
      child: Container(
        padding: EdgeInsets.all(22),
        color: color,
        width: MediaQuery.of(context).size.width < 1300
            ? MediaQuery.of(context).size.width - 100
            : MediaQuery.of(context).size.width / 5.5,
        height: MediaQuery.of(context).size.height / 6,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Icon(
                    icon,
                    size: 36,
                    color: Colors.white,
                  ),
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      // fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  number,
                  style: TextStyle(
                    fontSize: 34,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // getDataFromUi() async {
  //   DocumentSnapshot parkingRef = await FirebaseFirestore.instance
  //       .collection('admin_panel')
  //       .doc('central_park')
  //       .get();
  //   // parkingRef.data().forEach((key, value) {
  //   //   dashboardNumbers.add(value);
  //   //   print("$key,$value");
  //   // });
  //   // dashboardNumbers?.clear();
  //   // _value?.clear();
  //   parkingRef.data().forEach((key, value) {
  //     dashboardNumbers[key] = value;
  //     _value.add(value);
  //     print("$key,$value");
  //   });
  //   _isLoading = false;
  //   setState(() {});
  // }

  @override
  Widget build(BuildContext context) {
    Stream<DocumentSnapshot> _logs = FirebaseFirestore.instance
        .collection('admin_panel')
        .doc('central_park')
        .snapshots();
    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : Column(
              children: [
                StreamBuilder<DocumentSnapshot>(
                  stream: _logs,
                  builder: (context, snapshot) {
                    print("----dash snapshot $snapshot");
                    if (!snapshot.hasData) {
                      return Center(
                        child: Text("Loading ....."),
                      );
                    }
                    Map _dashBoardData = snapshot.data.data();
                    print("DashBoard Data : $_dashBoardData");
                    return Container(
                      margin: EdgeInsets.only(top: 12),
                      child: Column(
                        children: <Widget>[
                          MediaQuery.of(context).size.width < 1300
                              ? Column(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    customCard(
                                        colors[0],
                                        'Active Services',
                                        _dashBoardData['Active Services'],
                                        Icons.cleaning_services),
                                    customCard(
                                        colors[1],
                                        'Available Space',
                                        _dashBoardData['Available Space'],
                                        Icons.car_repair),
                                    customCard(
                                        colors[2],
                                        'Cost per Hour',
                                        _dashBoardData['Cost per Hour'],
                                        Icons.monetization_on),
                                    customCard(
                                        colors[3],
                                        'Total Cars Parked',
                                        _dashBoardData['Total Cars Parked'],
                                        Icons.car_rental),
                                  ],
                                  // children: List<Widget>.generate(
                                  //   _dashBoardData.values.toList().length,
                                  //   (i) {
                                  //     // List data =
                                  //     //     _dashBoardData.values.toList();
                                  //     // data.sort();
                                  //     print(
                                  //         "ticketsNumber: ${_dashBoardData.values.toList()[i]}");
                                  //     print(
                                  //         "newCount: ${_dashBoardData.keys.toList()[i]}");
                                  //     // return tickets(
                                  //     //     color: colors[i],
                                  //     //     context: context,
                                  //     //     // data: _dashBoardData);
                                  //     //     ticketsNumber:
                                  //     //         _dashBoardData.values.toList()[i],
                                  //     //     newCount:
                                  //     //         _dashBoardData.keys.toList()[i]);
                                  //     return
                                  //   },
                                  // ),
                                )
                              : Row(
                                  mainAxisAlignment:
                                      MainAxisAlignment.spaceAround,
                                  children: [
                                    customCard(
                                        colors[0],
                                        'Active Services',
                                        _dashBoardData['Active Services'],
                                        Icons.cleaning_services),
                                    customCard(
                                        colors[1],
                                        'Available Space',
                                        _dashBoardData['Available Space'],
                                        Icons.car_repair),
                                    customCard(
                                        colors[2],
                                        'Cost per Hour',
                                        _dashBoardData['Cost per Hour'],
                                        Icons.monetization_on),
                                    customCard(
                                        colors[3],
                                        'Total Cars Parked',
                                        _dashBoardData['Total Cars Parked'],
                                        Icons.car_rental),
                                  ],
                                  // children: List<Widget>.generate(
                                  //   _dashBoardData.values.toList().length,
                                  //   (i) {
                                  //     return tickets(
                                  //         color: colors[i],
                                  //         context: context,
                                  //         data: _dashBoardData);
                                  //     // ticketsNumber:
                                  //     //     _dashBoardData.values.toList()[i],
                                  //     // newCount:
                                  //     //     _dashBoardData.keys.toList()[i]);
                                  //   },
                                  // ),
                                ),
                          SizedBox(
                            height: 16,
                          ),
                        ],
                      ),
                    );
                  },
                ),
                /*----------*/
                // CustomScrollView(
                //   slivers: <Widget>[
                //     SliverList(
                //       delegate: SliverChildListDelegate([
                //         Container(
                //           margin: EdgeInsets.only(top: 12),
                //           child: Column(
                //             children: <Widget>[
                //               MediaQuery.of(context).size.width < 1300
                //                   ? Column(
                //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
                //                       children: List<Widget>.generate(4, (i) {
                //                         return tickets(colors[i], context, icons[i],
                //                             randomNumbers[i], newTexts[i]);
                //                       }),
                //                     )
                //                   : Row(
                //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
                //                       children: List<Widget>.generate(4, (i) {
                //                         return tickets(colors[i], context, icons[i],
                //                             randomNumbers[i], newTexts[i]);
                //                       })),
                //               SizedBox(
                //                 height: 16,
                //               ),
                //             ],
                //           ),
                //         ),
                //       ]),
                //     ),
                //     SliverGrid(
                //       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                //         crossAxisCount: MediaQuery.of(context).size.width > 1300 ? 4 : 3,
                //         childAspectRatio:
                //             MediaQuery.of(context).size.width < 1300 ? 0.6 : 0.65,
                //         mainAxisSpacing: 10,
                //       ),
                //       delegate: SliverChildBuilderDelegate(
                //         (BuildContext context, int index) {
                //           return Card(
                //             shape: RoundedRectangleBorder(
                //               borderRadius: BorderRadius.circular(5.0),
                //             ),
                //             elevation: 2,
                //             margin:
                //                 EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 20),
                //             child: Container(
                //               padding: EdgeInsets.all(12),
                //               child: Column(
                //                   crossAxisAlignment: CrossAxisAlignment.start,
                //                   children: [
                //                     Container(
                //                       child: Column(
                //                         crossAxisAlignment: CrossAxisAlignment.center,
                //                         //  mainAxisAlignment: MainAxisAlignment.spaceAround,
                //                         children: <Widget>[
                //                           Padding(
                //                             padding: const EdgeInsets.all(8.0),
                //                             child: Text(
                //                               "Beautiful Nature",
                //                               style: TextStyle(
                //                                 fontSize: 16,
                //                                 fontFamily: 'HelveticaNeue',
                //                               ),
                //                             ),
                //                           ),
                //                           Padding(
                //                             padding: const EdgeInsets.all(8.0),
                //                             child: Text(
                //                               '''The place is close to Metro Station and bus stop just 2 min by walk and near to "Naviglio" where you can enjoy the main night life in Milan.''',
                //                               textAlign: TextAlign.center,
                //                               style: TextStyle(
                //                                 fontSize: 14,
                //                                 fontWeight: FontWeight.bold,
                //                                 fontFamily: 'HelveticaNeue',
                //                               ),
                //                             ),
                //                           ),
                //                           Padding(
                //                             padding: const EdgeInsets.all(8.0),
                //                             child: Row(
                //                               mainAxisAlignment:
                //                                   MainAxisAlignment.spaceAround,
                //                               children: <Widget>[
                //                                 Text(
                //                                   "800/night",
                //                                   style: TextStyle(
                //                                     fontSize: 12,
                //                                     fontWeight: FontWeight.bold,
                //                                     fontFamily: 'HelveticaNeue',
                //                                   ),
                //                                 ),
                //                                 Row(
                //                                   children: <Widget>[
                //                                     Icon(Icons.location_on),
                //                                     Text(
                //                                       "Milan, Italy",
                //                                       style: TextStyle(
                //                                         fontSize: 12,
                //                                         fontWeight: FontWeight.bold,
                //                                         fontFamily: 'HelveticaNeue',
                //                                       ),
                //                                     )
                //                                   ],
                //                                 )
                //                               ],
                //                             ),
                //                           ),
                //                           SizedBox(
                //                             height: 8,
                //                           ),
                //                         ],
                //                       ),
                //                     ),
                //                   ]),
                //             ),
                //           );
                //         },
                //         childCount: 8,
                //       ),
                //     ),
                //     SliverGrid(
                //       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                //         crossAxisCount: MediaQuery.of(context).size.width > 1300 ? 4 : 3,
                //         childAspectRatio:
                //             MediaQuery.of(context).size.width < 1300 ? 0.6 : 0.65,
                //         mainAxisSpacing: 10,
                //       ),
                //       delegate: SliverChildBuilderDelegate(
                //         (BuildContext context, int index) {
                //           return Text('fgh');
                //         },
                //         childCount:3,
                //       ),
                //     )
                //   ],
                // ),
                Expanded(
                  child: StreamBuilder(
                    stream: logsRef
                        .orderBy('entry_timestamp', descending: true)
                        ?.snapshots(),
                    builder: (context, snapshot) {
                      print("******entered snapshot $snapshot");
                      if (!snapshot.hasData) {
                        return Center(
                          child: Text("Loading Logs....."),
                        );
                      }
                      return ListView.builder(
                        itemCount: snapshot.data.documents.length,
                        scrollDirection: Axis.vertical,
                        itemBuilder: (context, index) {
                          DocumentSnapshot document =
                              snapshot.data.documents[index];
                          return LogTile(
                            entryTimestamp: document["entry_timestamp"],
                            exitTimestamp: document['exit_timestamp'],
                            numberPlate: document["number_plate"],
                            place: document['place'],
                            paid: document['paid'] ?? '',
                            recent: false,
                          );
                        },
                      );
                    },
                  ),
                )
              ],
            ),
    );
  }
}
