import 'package:flutter/material.dart';
class ColorConstants {
  static Color blue = Color(0xFF0D46BB);
}
