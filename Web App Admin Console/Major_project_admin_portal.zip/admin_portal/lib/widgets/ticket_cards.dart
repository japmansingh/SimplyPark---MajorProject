import 'package:flutter/material.dart';

Widget tickets(
    {Color color,
    BuildContext context,
    String ticketsNumber,
    String newCount,
    Map data}) {
  print("Ticket screen $data");
  return Card(
    elevation: 2,
    child: Container(
      padding: EdgeInsets.all(22),
      color: color,
      width: MediaQuery.of(context).size.width < 1300
          ? MediaQuery.of(context).size.width - 100
          : MediaQuery.of(context).size.width / 5.5,
      height: MediaQuery.of(context).size.height / 6,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: <Widget>[
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: <Widget>[
                if (newCount == 'Address')
                  Icon(
                    Icons.local_parking,
                    size: 36,
                    color: Colors.white,
                  )
                else if (newCount == 'Available Space')
                  Icon(
                    Icons.car_repair,
                    size: 36,
                    color: Colors.white,
                  )
                else if (newCount == 'Cost per Hour')
                  Icon(
                    Icons.monetization_on,
                    size: 36,
                    color: Colors.white,
                  )
                else if (newCount == 'Total Cars Parked')
                  Icon(
                    Icons.car_rental,
                    size: 36,
                    color: Colors.white,
                  ),
                Text(
                  newCount ?? "",
                  style: TextStyle(
                    fontSize: 18,
                    color: Colors.white,
                    // fontWeight: FontWeight.bold,
                  ),
                )
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                ticketsNumber ?? "",
                style: TextStyle(
                  fontSize: 34,
                  color: Colors.white,
                  fontWeight: FontWeight.bold,
                ),
              ),
              // SizedBox(
              //   height: 8,
              // ),
              // Text(
              //   newCount,
              //   style: TextStyle(
              //     fontSize: 14,
              //     color: Colors.white,
              //     // fontWeight: FontWeight.bold,
              //     fontFamily: 'HelveticaNeue',
              //   ),
              // )
            ],
          ),
          // Expanded(
          //   child: Row(
          //     children: [
          //       for (String i in data.keys)
          //         Column(
          //           mainAxisAlignment: MainAxisAlignment.spaceBetween,
          //           children: <Widget>[
          //             Icon(
          //               Icons.local_parking,
          //               size: 36,
          //               color: Colors.white,
          //             ),
          //             Text(
          //               i ?? "",
          //               style: TextStyle(
          //                 fontSize: 18,
          //                 color: Colors.white,
          //                 // fontWeight: FontWeight.bold,
          //               ),
          //             ),
          //             Column(
          //               crossAxisAlignment: CrossAxisAlignment.end,
          //               mainAxisAlignment: MainAxisAlignment.center,
          //               children: <Widget>[
          //                 Text(
          //                   data['i'] ?? "",
          //                   style: TextStyle(
          //                     fontSize: 34,
          //                     color: Colors.white,
          //                     fontWeight: FontWeight.bold,
          //                   ),
          //                 ),
          //                 SizedBox(
          //                   height: 8,
          //                 ),
          //               ],
          //             ),
          //           ],
          //         ),
          //     ],
          //   ),
          // ),
        ],
      ),
    ),
  );
}
