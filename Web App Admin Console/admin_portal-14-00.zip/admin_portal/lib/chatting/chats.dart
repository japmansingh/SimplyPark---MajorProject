import 'dart:convert';

import 'package:admin_portal/chatting/support.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class Chats extends StatefulWidget {
  const Chats({Key key}) : super(key: key);

  @override
  _ChatsState createState() => _ChatsState();
}

class _ChatsState extends State<Chats> {
  Map<String, Map> chattingUsers = {};

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: StreamBuilder<QuerySnapshot>(
        stream: FirebaseFirestore.instance
            .collection('support')
            .orderBy("timestamp", descending: true)
            .snapshots(),
        builder: (context, snapshot) {
          if (!snapshot.hasData) {
            return Center(
              child: CircularProgressIndicator(),
            );
          }
          print("snap length");
          print(snapshot.data.docs.length);

          snapshot.data.docs.forEach((doc) {
            print(doc.id);
            FirebaseFirestore.instance
                .collection('users')
                .doc(doc.id)
                .get()
                .then((documentSnapshot) {
              // chattingUsers.(documentSnapshot.data());
              Map userData = documentSnapshot.data();
              chattingUsers[userData["username"]] = userData;
              print(chattingUsers);
            });
          });
          return ListView.builder(
            itemCount: chattingUsers.length,
            itemBuilder: (context, index) {
              String userName = chattingUsers.keys.toList()[index];
              Map userData = chattingUsers.values.toList()[index];
              return GestureDetector(
                onTap: () => Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => Support(
                      chatUserId: userData['id'],
                      chatUserMap: userData,
                    ),
                  ),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(15.0),
                  child: Container(
                    width: MediaQuery.of(context).size.width,
                    child: Card(
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(50.0),
                      ),
                      elevation: 5.0,
                      color: Colors.blueGrey.shade100,
                      child: Row(
                        children: [
                          ClipRRect(
                            borderRadius: BorderRadius.circular(100.0),
                            child: Container(
                              height: 100,
                              child: CachedNetworkImage(
                                imageUrl: userData['photoUrl'],
                                fit: BoxFit.cover,
                              ),
                            ),
                          ),
                          SizedBox(
                            width: 25.0,
                          ),
                          Expanded(
                            child: Text(
                              userData["username"].toString().toUpperCase(),
                              style: TextStyle(fontSize: 20.0),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }
}
