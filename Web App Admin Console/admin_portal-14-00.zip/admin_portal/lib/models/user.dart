class User {
  String address = '';
  String name = '';
  String activeServices = '';
  String availableSpace = '';
  String basePay = '';
  String costPerHour = '';
  String totalCarsParked = '';

  save() {
    print('saving user using a web service');
  }
}
