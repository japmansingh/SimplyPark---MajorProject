import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class DashBoardRepository with ChangeNotifier {
  // DashBoardRepository() {
  //   getDataFromUi();
  // }

  Map _dashBoardData;

  Map get dashBoardData => _dashBoardData;

  // getDataFromUi() async {
  //   DocumentSnapshot parkingRef = await FirebaseFirestore.instance
  //       .collection('admin_panel')
  //       .doc('central_park')
  //       .get();
  //
  //   parkingRef.data().forEach((key, value) {
  //     _dashBoardData[key] = value;
  //     print("$key,$value");
  //   });
  //   notifyListeners();
  // }
}
