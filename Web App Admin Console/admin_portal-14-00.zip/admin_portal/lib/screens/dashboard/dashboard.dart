import 'dart:async';
import 'package:admin_portal/utils/raw_data.dart';
import 'package:admin_portal/widgets/log_tile.dart';
import 'package:admin_portal/widgets/ticket_cards.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:flutter/material.dart';
import 'package:cloud_firestore/cloud_firestore.dart';

class Dashboard extends StatefulWidget {
  @override
  _DashboardState createState() => _DashboardState();
}

class _DashboardState extends State<Dashboard> {
  bool _isLoading = true;
  int _payRate = 30;
  double calChg = 0;
  bool _notParked = true;
  final logsRef = FirebaseFirestore.instance
      .collection('admin_panel')
      .doc('central_park')
      .collection('parking');

  @override
  void initState() {
    super.initState();
    Timer(Duration(seconds: 1), () {
      setState(() {
        _isLoading = false;
      });
    });
  }

  customCard(Color color, String title, String number, IconData icon) {
    return Card(
      elevation: 2,
      child: Container(
        padding: EdgeInsets.all(22),
        color: color,
        width: MediaQuery.of(context).size.width < 1300
            ? MediaQuery.of(context).size.width - 100
            : MediaQuery.of(context).size.width / 5.5,
        height: MediaQuery.of(context).size.height / 6,
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: <Widget>[
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: <Widget>[
                  Icon(
                    icon,
                    size: 36,
                    color: Colors.white,
                  ),
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 18,
                      color: Colors.white,
                      // fontWeight: FontWeight.bold,
                    ),
                  )
                ],
              ),
            ),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Text(
                  number,
                  style: TextStyle(
                    fontSize: 34,
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  newLogTile(BuildContext context, DocumentSnapshot document) {
    String entry = document['entry_timestamp'];
    print("*******************$entry");

    int entryHr = int.parse(entry.substring(11, 13));
    int entryMn = int.parse(entry.substring(14, 16));
    String exit = "";
    int exitHr = 0;
    int exitMn = 0;
    try {
      exit = document['exit_timestamp'];
      exitHr = int.parse(exit.substring(11, 13));
      exitMn = int.parse(exit.substring(14, 16));
      calChg = (exitHr - entryHr) * _payRate +
          ((exitMn - entryMn) * (_payRate / 60))+50;
      print("Charge : $calChg");
      _notParked = true;
    } catch (e) {
      print(e);
      exit = "Vehicle in Parking";
      _notParked = false;
    }
    if (document["imageUrl"] != null)
      return InkWell(
        // onTap: () => Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //       builder: (context) => DetailedNumPltSrn(document.data())),
        // ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            height: 200,
            width: MediaQuery.of(context).size.width / 2,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.grey[200]),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      bottomLeft: Radius.circular(10)),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10)),
                      color: Colors.black,
                    ),
                    width: 350,
                    height: 200,
                    child: CachedNetworkImage(
                      imageUrl: document["imageUrl"] ?? "",
                      placeholder: (context, url) =>
                          Center(child: CircularProgressIndicator()),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        top: 15.0, right: 15.0, bottom: 15.0, left: 5.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Row(
                              children: [
                                Container(
                                  height: 40,
                                  width:
                                      MediaQuery.of(context).size.width / 4.5,
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: Colors.black,
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Center(
                                    child: Text(
                                      '${document['number_plate']}',
                                      // '${document["place"]}',
                                      style: TextStyle(color: Colors.white),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 40,
                                  width:
                                      MediaQuery.of(context).size.width / 6.5,
                                  decoration: BoxDecoration(
                                      color: (document['paid'] == "paid")
                                          ? Colors.green
                                          : Colors.redAccent,
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Center(
                                    child: Text(
                                      (document['paid'] == "paid")
                                          ? "Paid"
                                          : "Not Paid",
                                      style: TextStyle(color: Colors.white),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            _notParked
                                ? Row(
                                    children: [
                                      Text(
                                        '₹',
                                        style: TextStyle(color: Colors.green),
                                      ),
                                      Text(
                                        "$calChg",
                                        style: TextStyle(color: Colors.green),
                                      )
                                    ],
                                  )
                                : Container(
                                    height: 0.0,
                                    width: 0.0,
                                  ),
                          ],
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Text(
                              'Place: ${document['place']}',
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Text(
                              "Entry Timestamp:",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Text(
                              "Date: ${entry.substring(0, 10)}    Time: ${entry.substring(11, 19)}",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: Text(
                            'Exit Timestamp:',
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                            softWrap: false,
                            maxLines: 1,
                          ),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        _notParked
                            ? Padding(
                                padding: const EdgeInsets.only(left: 5.0),
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width / 1.2,
                                  child: Text(
                                    "Date: ${exit?.substring(0, 10)}    Time: ${exit?.substring(11, 19)}",
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    softWrap: false,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(left: 5.0),
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width / 1.2,
                                  child: Text(
                                    exit,
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.green.shade800,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    softWrap: false,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                        _notParked
                            ? Padding(
                                padding: const EdgeInsets.only(left: 5.0),
                                child: Text(
                                  "Parked for: ${exitHr - entryHr} hr. and ${exitMn - entryMn} min.",
                                  style: TextStyle(
                                    color: Colors.green.shade900,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              )
                            : Container(
                                height: 0.0,
                                width: 0.0,
                              ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
  }

  // getDataFromUi() async {
  //   DocumentSnapshot parkingRef = await FirebaseFirestore.instance
  //       .collection('admin_panel')
  //       .doc('central_park')
  //       .get();
  //   // parkingRef.data().forEach((key, value) {
  //   //   dashboardNumbers.add(value);
  //   //   print("$key,$value");
  //   // });
  //   // dashboardNumbers?.clear();
  //   // _value?.clear();
  //   parkingRef.data().forEach((key, value) {
  //     dashboardNumbers[key] = value;
  //     _value.add(value);
  //     print("$key,$value");
  //   });
  //   _isLoading = false;
  //   setState(() {});
  // }

  @override
  Widget build(BuildContext context) {
    Stream<DocumentSnapshot> _logs = FirebaseFirestore.instance
        .collection('admin_panel')
        .doc('central_park')
        .snapshots();
    return Scaffold(
      body: _isLoading
          ? Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              child: Column(
                children: [
                  StreamBuilder<DocumentSnapshot>(
                    stream: _logs,
                    builder: (context, snapshot) {
                      print("----dash snapshot $snapshot");
                      if (!snapshot.hasData) {
                        return Center(
                          child: Text("Loading ....."),
                        );
                      }
                      Map _dashBoardData = snapshot.data.data();
                      print("DashBoard Data : $_dashBoardData");
                      return Container(
                        margin: EdgeInsets.only(top: 12),
                        child: Column(
                          children: <Widget>[
                            MediaQuery.of(context).size.width < 1300
                                ? Column(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      customCard(
                                          colors[0],
                                          'Active Services',
                                          _dashBoardData['Active_Services'],
                                          Icons.cleaning_services),
                                      customCard(
                                          colors[1],
                                          'Available Space',
                                          _dashBoardData['Available_Space'],
                                          Icons.car_repair),
                                      customCard(
                                          colors[2],
                                          'Cost per Hour',
                                          _dashBoardData['Cost_per_Hour'],
                                          Icons.monetization_on),
                                      customCard(
                                          colors[3],
                                          'Total Cars Parked',
                                          _dashBoardData['Total_Cars_Parked'],
                                          Icons.car_rental),
                                    ],
                                    // children: List<Widget>.generate(
                                    //   _dashBoardData.values.toList().length,
                                    //   (i) {
                                    //     // List data =
                                    //     //     _dashBoardData.values.toList();
                                    //     // data.sort();
                                    //     print(
                                    //         "ticketsNumber: ${_dashBoardData.values.toList()[i]}");
                                    //     print(
                                    //         "newCount: ${_dashBoardData.keys.toList()[i]}");
                                    //     // return tickets(
                                    //     //     color: colors[i],
                                    //     //     context: context,
                                    //     //     // data: _dashBoardData);
                                    //     //     ticketsNumber:
                                    //     //         _dashBoardData.values.toList()[i],
                                    //     //     newCount:
                                    //     //         _dashBoardData.keys.toList()[i]);
                                    //     return
                                    //   },
                                    // ),
                                  )
                                : Row(
                                    mainAxisAlignment:
                                        MainAxisAlignment.spaceAround,
                                    children: [
                                      customCard(
                                          colors[0],
                                          'Active Services',
                                          _dashBoardData['Active_Services'],
                                          Icons.cleaning_services),
                                      customCard(
                                          colors[1],
                                          'Available Space',
                                          _dashBoardData['Available_Space'],
                                          Icons.car_repair),
                                      customCard(
                                          colors[2],
                                          'Cost per Hour',
                                          _dashBoardData['Cost_per_Hour'],
                                          Icons.monetization_on),
                                      customCard(
                                          colors[3],
                                          'Total Cars Parked',
                                          _dashBoardData['Total_Cars_Parked'],
                                          Icons.car_rental),
                                    ],
                                    // children: List<Widget>.generate(
                                    //   _dashBoardData.values.toList().length,
                                    //   (i) {
                                    //     return tickets(
                                    //         color: colors[i],
                                    //         context: context,
                                    //         data: _dashBoardData);
                                    //     // ticketsNumber:
                                    //     //     _dashBoardData.values.toList()[i],
                                    //     // newCount:
                                    //     //     _dashBoardData.keys.toList()[i]);
                                    //   },
                                    // ),
                                  ),
                            SizedBox(
                              height: 16,
                            ),
                          ],
                        ),
                      );
                    },
                  ),
                  Padding(
                    padding: const EdgeInsets.all(15.0),
                    child: Text(
                      "Recently Parked Vehicles:",
                      style: TextStyle(fontSize: 20),
                    ),
                  ),
                  /*----------*/
                  // CustomScrollView(
                  //   slivers: <Widget>[
                  //     SliverList(
                  //       delegate: SliverChildListDelegate([
                  //         Container(
                  //           margin: EdgeInsets.only(top: 12),
                  //           child: Column(
                  //             children: <Widget>[
                  //               MediaQuery.of(context).size.width < 1300
                  //                   ? Column(
                  //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
                  //                       children: List<Widget>.generate(4, (i) {
                  //                         return tickets(colors[i], context, icons[i],
                  //                             randomNumbers[i], newTexts[i]);
                  //                       }),
                  //                     )
                  //                   : Row(
                  //                       mainAxisAlignment: MainAxisAlignment.spaceAround,
                  //                       children: List<Widget>.generate(4, (i) {
                  //                         return tickets(colors[i], context, icons[i],
                  //                             randomNumbers[i], newTexts[i]);
                  //                       })),
                  //               SizedBox(
                  //                 height: 16,
                  //               ),
                  //             ],
                  //           ),
                  //         ),
                  //       ]),
                  //     ),
                  //     SliverGrid(
                  //       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  //         crossAxisCount: MediaQuery.of(context).size.width > 1300 ? 4 : 3,
                  //         childAspectRatio:
                  //             MediaQuery.of(context).size.width < 1300 ? 0.6 : 0.65,
                  //         mainAxisSpacing: 10,
                  //       ),
                  //       delegate: SliverChildBuilderDelegate(
                  //         (BuildContext context, int index) {
                  //           return Card(
                  //             shape: RoundedRectangleBorder(
                  //               borderRadius: BorderRadius.circular(5.0),
                  //             ),
                  //             elevation: 2,
                  //             margin:
                  //                 EdgeInsets.only(left: 10, right: 10, top: 10, bottom: 20),
                  //             child: Container(
                  //               padding: EdgeInsets.all(12),
                  //               child: Column(
                  //                   crossAxisAlignment: CrossAxisAlignment.start,
                  //                   children: [
                  //                     Container(
                  //                       child: Column(
                  //                         crossAxisAlignment: CrossAxisAlignment.center,
                  //                         //  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  //                         children: <Widget>[
                  //                           Padding(
                  //                             padding: const EdgeInsets.all(8.0),
                  //                             child: Text(
                  //                               "Beautiful Nature",
                  //                               style: TextStyle(
                  //                                 fontSize: 16,
                  //                                 fontFamily: 'HelveticaNeue',
                  //                               ),
                  //                             ),
                  //                           ),
                  //                           Padding(
                  //                             padding: const EdgeInsets.all(8.0),
                  //                             child: Text(
                  //                               '''The place is close to Metro Station and bus stop just 2 min by walk and near to "Naviglio" where you can enjoy the main night life in Milan.''',
                  //                               textAlign: TextAlign.center,
                  //                               style: TextStyle(
                  //                                 fontSize: 14,
                  //                                 fontWeight: FontWeight.bold,
                  //                                 fontFamily: 'HelveticaNeue',
                  //                               ),
                  //                             ),
                  //                           ),
                  //                           Padding(
                  //                             padding: const EdgeInsets.all(8.0),
                  //                             child: Row(
                  //                               mainAxisAlignment:
                  //                                   MainAxisAlignment.spaceAround,
                  //                               children: <Widget>[
                  //                                 Text(
                  //                                   "800/night",
                  //                                   style: TextStyle(
                  //                                     fontSize: 12,
                  //                                     fontWeight: FontWeight.bold,
                  //                                     fontFamily: 'HelveticaNeue',
                  //                                   ),
                  //                                 ),
                  //                                 Row(
                  //                                   children: <Widget>[
                  //                                     Icon(Icons.location_on),
                  //                                     Text(
                  //                                       "Milan, Italy",
                  //                                       style: TextStyle(
                  //                                         fontSize: 12,
                  //                                         fontWeight: FontWeight.bold,
                  //                                         fontFamily: 'HelveticaNeue',
                  //                                       ),
                  //                                     )
                  //                                   ],
                  //                                 )
                  //                               ],
                  //                             ),
                  //                           ),
                  //                           SizedBox(
                  //                             height: 8,
                  //                           ),
                  //                         ],
                  //                       ),
                  //                     ),
                  //                   ]),
                  //             ),
                  //           );
                  //         },
                  //         childCount: 8,
                  //       ),
                  //     ),
                  //     SliverGrid(
                  //       gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  //         crossAxisCount: MediaQuery.of(context).size.width > 1300 ? 4 : 3,
                  //         childAspectRatio:
                  //             MediaQuery.of(context).size.width < 1300 ? 0.6 : 0.65,
                  //         mainAxisSpacing: 10,
                  //       ),
                  //       delegate: SliverChildBuilderDelegate(
                  //         (BuildContext context, int index) {
                  //           return Text('fgh');
                  //         },
                  //         childCount:3,
                  //       ),
                  //     )
                  //   ],
                  // ),
                  Container(
                    height: MediaQuery.of(context).size.height / 1.6,
                    child: StreamBuilder(
                      stream: logsRef
                          .orderBy('entry_timestamp', descending: true)
                          ?.snapshots(),
                      builder: (context, snapshot) {
                        print("******entered snapshot $snapshot");
                        if (!snapshot.hasData) {
                          return Center(
                            child: Text("Loading Logs....."),
                          );
                        }
                        return ListView.builder(
                          itemCount: snapshot.data.documents.length,
                          scrollDirection: Axis.vertical,
                          itemBuilder: (context, index) {
                            DocumentSnapshot document =
                                snapshot.data.documents[index];
                            return newLogTile(context, document);
                            // return LogTile(
                            //   entryTimestamp: document["entry_timestamp"],
                            //   exitTimestamp: document['exit_timestamp'],
                            //   numberPlate: document["number_plate"],
                            //   place: document['place'],
                            //   paid: document['paid'] ?? '',
                            //   recent: false,
                            // );
                          },
                        );
                      },
                    ),
                  )
                ],
              ),
            ),
    );
  }
}
