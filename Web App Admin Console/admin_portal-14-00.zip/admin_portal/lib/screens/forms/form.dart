import 'package:admin_portal/models/user.dart';
import 'package:admin_portal/utils/color_constants.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class FormMaterial extends StatefulWidget {
  @override
  _FormMaterialState createState() => _FormMaterialState();
}

class _FormMaterialState extends State<FormMaterial> {
  final _formKey = GlobalKey<FormState>();
  final _user = User();
  TextEditingController _controller1 = TextEditingController();
  TextEditingController _controller2 = TextEditingController();
  TextEditingController _controller3 = TextEditingController();
  TextEditingController _controller4 = TextEditingController();
  TextEditingController _controller5 = TextEditingController();
  TextEditingController _controller6 = TextEditingController();
  TextEditingController _controller7 = TextEditingController();

  @override
  void initState() {
    super.initState();
    getData();
  }

  getData() async {
    await FirebaseFirestore.instance
        .collection('admin_panel')
        .doc('central_park')
        .get()
        .then((doc) {
      Map data = doc.data();
      print(data);
      _controller1.text = doc.id.replaceAll("_", " ").toUpperCase();
      _controller2.text = data['Address'];
      _controller3.text = data['Active_Services'];
      _controller4.text = data['Available_Space'];
      _controller5.text = data['Base_Pay'];
      _controller6.text = data['Cost_per_Hour'];
      _controller7.text = data['Total_Cars_Parked'];
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Card(
        elevation: 2,
        margin: EdgeInsets.fromLTRB(64, 32, 64, 64),
        child: Padding(
          padding: const EdgeInsets.all(32.0),
          child: Container(
            padding:
                const EdgeInsets.symmetric(vertical: 16.0, horizontal: 16.0),
            child: Builder(
              builder: (context) => Form(
                key: _formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Container(
                      child: Text(
                        'Edit Details:',
                        style: TextStyle(
                          fontSize: 24,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    TextFormField(
                      readOnly: true,
                      controller: _controller1,
                      style: TextStyle(),
                      decoration: InputDecoration(
                        labelText: 'Parking name',
                        labelStyle: TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your first name';
                        }
                      },
                      onSaved: (val) => setState(() => _user.name = val),
                    ),
                    TextFormField(
                        controller: _controller2,
                        decoration: InputDecoration(
                          labelText: 'Address',
                          labelStyle: TextStyle(
                            fontSize: 18,
                            color: Colors.black,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        validator: (value) {
                          if (value.isEmpty) {
                            return 'Please enter your last name.';
                          }
                        },
                        onSaved: (val) => setState(() => _user.address = val)),
                    TextFormField(
                      controller: _controller3,
                      style: TextStyle(),
                      decoration: InputDecoration(
                        labelText: 'Active Services',
                        labelStyle: TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your first name';
                        }
                      },
                      onSaved: (val) =>
                          setState(() => _user.activeServices = val),
                    ),
                    TextFormField(
                      controller: _controller4,
                      style: TextStyle(),
                      decoration: InputDecoration(
                        labelText: 'Available Space',
                        labelStyle: TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your first name';
                        }
                      },
                      onSaved: (val) =>
                          setState(() => _user.availableSpace = val),
                    ),
                    TextFormField(
                      controller: _controller5,
                      style: TextStyle(),
                      decoration: InputDecoration(
                        labelText: 'Base Pay',
                        labelStyle: TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your first name';
                        }
                      },
                      onSaved: (val) => setState(() => _user.basePay = val),
                    ),
                    TextFormField(
                      controller: _controller6,
                      style: TextStyle(),
                      decoration: InputDecoration(
                        labelText: 'Cost per Hour',
                        labelStyle: TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your first name';
                        }
                      },
                      onSaved: (val) => setState(() => _user.costPerHour = val),
                    ),
                    TextFormField(
                      controller: _controller7,
                      style: TextStyle(),
                      decoration: InputDecoration(
                        labelText: 'Total Cars Parked',
                        labelStyle: TextStyle(
                          fontSize: 18,
                          color: Colors.black,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      validator: (value) {
                        if (value.isEmpty) {
                          return 'Please enter your first name';
                        }
                      },
                      onSaved: (val) =>
                          setState(() => _user.totalCarsParked = val),
                    ),
                    Container(
                      height: 80,
                      // margin: EdgeInsets.only(left: 200, right: 200),
                      padding: const EdgeInsets.symmetric(
                          vertical: 16.0, horizontal: 16.0),
                      child: RaisedButton(
                        color: ColorConstants.blue,
                        onPressed: () async {
                          if (_formKey.currentState.validate()) {
                            _formKey.currentState.save();
                            _user.save();
                            _showDialog(context);
                            print(_user);
                            await FirebaseFirestore.instance
                                .collection('admin_panel')
                                .doc('central_park')
                                .update({
                              'Address': _user.address,
                              'Active_Services': _user.activeServices,
                              'Available_Space': _user.availableSpace,
                              'Base_Pay': _user.basePay,
                              'Cost_per_Hour': _user.costPerHour,
                              'Total_Cars_Parked': _user.totalCarsParked,
                            });
                            _controller2.text = _user.address;
                            _controller3.text = _user.activeServices;
                            _controller4.text = _user.availableSpace;
                            _controller5.text = _user.basePay;
                            _controller6.text = _user.costPerHour;
                            _controller7.text = _user.totalCarsParked;
                          }
                        },
                        child: Text(
                          'Save',
                          style: TextStyle(
                            fontSize: 16,
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                        // SwitchListTile(
                        //     title: const Text(
                        //       'To our Monthly Subscription',
                        //       style: TextStyle(
                        //         fontSize: 18,
                        //         color: Colors.black,
                        //       ),
                        //     ),
                        //     value: _user.monthlyNewsletter,
                        //     onChanged: (bool val) =>
                        //         setState(() => _user.monthlyNewsletter = val)),
                        // Container(
                        //   padding: const EdgeInsets.fromLTRB(0, 50, 0, 20),
                        //   child: Text(
                        //     'Interests',
                        //     style: TextStyle(
                        //       fontSize: 24,
                        //       color: Colors.black,
                        //       fontWeight: FontWeight.bold,
                        //     ),
                        //   ),
                        // ),
                        // CheckboxListTile(
                        //     title: const Text(
                        //       'Writing',
                        //       style: TextStyle(
                        //         fontSize: 18,
                        //         color: Colors.black,
                        //       ),
                        //     ),
                        //     value: _user.passions[User.PassionWriting],
                        //     onChanged: (val) {
                        //       setState(
                        //           () => _user.passions[User.PassionWriting] = val);
                        //     }),
                      ),
                    )
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  _showDialog(BuildContext context) {
    Scaffold.of(context)
        .showSnackBar(SnackBar(content: Text('Saving Details...')));
  }
}
