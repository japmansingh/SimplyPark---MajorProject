import 'package:admin_portal/widgets/log_tile.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class History extends StatefulWidget {
  const History({Key key}) : super(key: key);

  @override
  _HistoryState createState() => _HistoryState();
}

class _HistoryState extends State<History> {
  int _payRate = 30;
  double calChg = 0;
  bool _notParked = true;

  final logsRef = FirebaseFirestore.instance
      .collection('admin_panel')
      .doc('central_park')
      .collection('history');
  ScrollController _controller;

  @override
  void initState() {
    super.initState();
    _controller = ScrollController();
  }

  newLogTile(BuildContext context, DocumentSnapshot document) {
    String entry = document['entry_timestamp'];
    print("*******************$entry");

    int entryHr = int.parse(entry.substring(11, 13));
    int entryMn = int.parse(entry.substring(14, 16));
    String exit = "";
    int exitHr = 0;
    int exitMn = 0;
    try {
      exit = document['exit_timestamp'];
      exitHr = int.parse(exit.substring(11, 13));
      exitMn = int.parse(exit.substring(14, 16));
      calChg = (exitHr - entryHr) * _payRate +
          ((exitMn - entryMn) * (_payRate / 60))+50;
      print("Charge : $calChg");
      _notParked = true;
    } catch (e) {
      print(e);
      exit = "Vehicle in Parking";
      _notParked = false;
    }
    if (document["imageUrl"] != null)
      return InkWell(
        // onTap: () => Navigator.push(
        //   context,
        //   MaterialPageRoute(
        //       builder: (context) => DetailedNumPltSrn(document.data())),
        // ),
        child: Padding(
          padding: const EdgeInsets.all(8.0),
          child: Container(
            height: 200,
            width: MediaQuery.of(context).size.width / 2,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(10),
                color: Colors.grey[200]),
            child: Row(
              children: [
                ClipRRect(
                  borderRadius: BorderRadius.only(
                      topLeft: Radius.circular(10),
                      bottomLeft: Radius.circular(10)),
                  child: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.only(
                          topLeft: Radius.circular(10),
                          bottomLeft: Radius.circular(10)),
                      color: Colors.black,
                    ),
                    width: 350,
                    height: 200,
                    child: CachedNetworkImage(
                      imageUrl: document["imageUrl"] ?? "",
                      placeholder: (context, url) =>
                          Center(child: CircularProgressIndicator()),
                      errorWidget: (context, url, error) => Icon(Icons.error),
                      fit: BoxFit.fill,
                    ),
                  ),
                ),
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.only(
                        top: 15.0, right: 15.0, bottom: 15.0, left: 5.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          mainAxisSize: MainAxisSize.max,
                          children: [
                            Row(
                              children: [
                                Container(
                                  height: 40,
                                  width:
                                      MediaQuery.of(context).size.width / 4.5,
                                  padding: const EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                      color: Colors.black,
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Center(
                                    child: Text(
                                      '${document['number_plate']}',
                                      // '${document["place"]}',
                                      style: TextStyle(color: Colors.white),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ),
                                ),
                                Container(
                                  height: 40,
                                  width:
                                      MediaQuery.of(context).size.width / 6.5,
                                  decoration: BoxDecoration(
                                      color: (document['paid'] == "paid")
                                          ? Colors.green
                                          : Colors.redAccent,
                                      borderRadius: BorderRadius.circular(20)),
                                  child: Center(
                                    child: Text(
                                      (document['paid'] == "paid")
                                          ? "Paid"
                                          : "Not Paid",
                                      style: TextStyle(color: Colors.white),
                                      overflow: TextOverflow.ellipsis,
                                      maxLines: 1,
                                    ),
                                  ),
                                ),
                              ],
                            ),
                            _notParked
                                ? Row(
                                    children: [
                                      Text(
                                        '₹',
                                        style: TextStyle(color: Colors.green),
                                      ),
                                      Text(
                                        "$calChg",
                                        style: TextStyle(color: Colors.green),
                                      )
                                    ],
                                  )
                                : Container(
                                    height: 0.0,
                                    width: 0.0,
                                  ),
                          ],
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Text(
                              'Place: ${document['place']}',
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Text(
                              "Entry Timestamp:",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width / 1.2,
                            child: Text(
                              "Date: ${entry.substring(0, 10)}    Time: ${entry.substring(11, 19)}",
                              style: TextStyle(
                                fontSize: 15,
                                color: Colors.black,
                                fontWeight: FontWeight.bold,
                              ),
                              maxLines: 1,
                              softWrap: false,
                              overflow: TextOverflow.ellipsis,
                            ),
                          ),
                        ),
                        SizedBox(
                          height: 5,
                        ),
                        Padding(
                          padding: const EdgeInsets.only(left: 5.0),
                          child: Text(
                            'Exit Timestamp:',
                            style: TextStyle(
                              fontSize: 15,
                              color: Colors.black,
                              fontWeight: FontWeight.bold,
                            ),
                            overflow: TextOverflow.ellipsis,
                            softWrap: false,
                            maxLines: 1,
                          ),
                        ),
                        SizedBox(
                          height: 3,
                        ),
                        _notParked
                            ? Padding(
                                padding: const EdgeInsets.only(left: 5.0),
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width / 1.2,
                                  child: Text(
                                    "Date: ${exit?.substring(0, 10)}    Time: ${exit?.substring(11, 19)}",
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.black,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    softWrap: false,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              )
                            : Padding(
                                padding: const EdgeInsets.only(left: 5.0),
                                child: SizedBox(
                                  width:
                                      MediaQuery.of(context).size.width / 1.2,
                                  child: Text(
                                    exit,
                                    style: TextStyle(
                                      fontSize: 15,
                                      color: Colors.green.shade800,
                                      fontWeight: FontWeight.bold,
                                    ),
                                    maxLines: 1,
                                    softWrap: false,
                                    overflow: TextOverflow.ellipsis,
                                  ),
                                ),
                              ),
                        _notParked
                            ? Padding(
                                padding: const EdgeInsets.only(left: 5.0),
                                child: Text(
                                  "Parked for: ${exitHr - entryHr} hr. and ${exitMn - entryMn} min.",
                                  style: TextStyle(
                                    color: Colors.green.shade900,
                                    fontSize: 15,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                              )
                            : Container(
                                height: 0.0,
                                width: 0.0,
                              ),
                      ],
                    ),
                  ),
                )
              ],
            ),
          ),
        ),
      );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SingleChildScrollView(
        controller: _controller,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: Text(
                "History of all Parked Vehicles:",
                style: TextStyle(fontSize: 20),
              ),
            ),
            Container(
              height: MediaQuery.of(context).size.height/1.2,
              child: StreamBuilder(
                stream: logsRef
                    .orderBy('exit_timestamp', descending: true)
                    ?.snapshots(),
                builder: (context, snapshot) {
                  print("******History entered snapshot $snapshot");
                  if (!snapshot.hasData) {
                    return Center(
                      child: Text("Loading Logs....."),
                    );
                  }
                  return ListView.builder(
                    itemCount: snapshot.data.documents.length,
                    scrollDirection: Axis.vertical,
                    itemBuilder: (context, index) {
                      DocumentSnapshot document =
                          snapshot.data.documents[index];
                      return newLogTile(context, document);
                      // return LogTile(
                      //   entryTimestamp: document["entry_timestamp"],
                      //   exitTimestamp: document['exit_timestamp'],
                      //   numberPlate: document["number_plate"],
                      //   place: document['place'],
                      //   paid: document['paid'] ?? '',
                      //   recent: false,
                      // );
                    },
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
